import { Link } from "react-router-dom";
import Header from "../Header";

export default function IndexPage() {
    return (
        <div>
            index page here
        </div>
    );
}